from setuptools import setup

setup(name='calculi',
      version='0.1',
      description='Gaussian and Binomial distributions',
      author = 'Saviour Eking',
      author_Email = 'saviour.eking@outlook.com',
      packages=['calculi'],
      zip_safe=False)
